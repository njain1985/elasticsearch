#!/bin/bash
go build
GOOS=windows go build
name=$(basename $PWD)
zip     ${name}.zip ${name} ${name}.exe *.yaml *.yml *.md *.txt LICENSE
