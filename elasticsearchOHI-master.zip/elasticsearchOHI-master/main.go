package main

import (
	"encoding/json"
	"github.com/jeremywohl/flatten"
	"github.com/newrelic/infra-integrations-sdk/data/metric"
	"github.com/newrelic/infra-integrations-sdk/integration"
	"log"
	"net/http"
	"net/url"
	"strings"
	"time"
	"fmt"
	"os"
)

func main() {
	ohi, err := integration.New(getConfig().Integrationname, getConfig().Integrationversion, integration.Args(nil))
	if err != nil {
		log.Fatal(err)
	}

	for _, api := range getConfig().Apis {
		processApi(ohi, api)
	}
	err = ohi.Publish()
}

func init() {
}

func processApi(ohi *integration.Integration, api Api) {
	//log.Printf(api.Url)
	var netClient = &http.Client{
		Timeout: time.Second * 10,
	}
	response, err := netClient.Get(api.Url)
	if err != nil {
		log.Fatalf("reading response body: %v", err)
	}
	defer response.Body.Close()

	var results interface{}
	err = json.NewDecoder(response.Body).Decode(&results)
	if err != nil {
		log.Fatalf("reading response body: %v", err)
	}

	// Type assert results so we can flatten it
	m := results.(map[string]interface{})
	flat, err := flatten.Flatten(m, "", flatten.DotStyle)
	if api.Debug{
		for k,v := range flat{
			fmt.Fprintf(os.Stderr, "%v: %v\n", k, v)
		}
	}

	entity, err := newEntity(ohi, api)
	// Sets event_type
	//var metricSet *metric.Set
	 metricSet, err := entity.NewMetricSet(getEventType(api))
	// This might be a problem
	var p string
	for k, v := range flat {
		if discard(k, api.Discard) {
			continue
		}
		if x, y, ok := entityBreak(k, api); ok {
			// Don't send empty sets, an empty set will have one entry for event_type
			if len(metricSet.Metrics) > 1 {
				entity, err = newEntity(ohi, api)
				metricSet, err = entity.NewMetricSet(getEventType(api))
			}
			metricSet.SetMetric(x, y, metric.ATTRIBUTE)
			p = x + "." + y + "."
		}
		// Process the ones we want
		metricSet.SetMetric(strings.Replace(k, p, "", 1), v, getSourceType(v))
	}
}

func getEventType(api Api) (eventType string) {
	s := api.Source
	u, _ := url.Parse(api.Url)
	r:= s + " "+ (u.Path)
	r = strings.Replace(r, "_", " ", -1)
	r = strings.Replace(r, "/", " ", -1)
	return strings.Replace(strings.Title(r), " ", "", -1)
}

func getSourceType(i interface{}) (mst metric.SourceType) {
	if _, ok := i.(string); ok {
		return metric.ATTRIBUTE
	}
	return metric.GAUGE
}

var breakValue map[string]interface{} = make(map[string]interface{})

func entityBreak(s string, api Api) (k, v string, ok bool) {
	// Test each break prefix
	for _, k := range api.Split {
		if strings.HasPrefix(s, k) {
			// Extract the value
			s = strings.Replace(s, k+".", "", 1)
			v := strings.Split(s, ".")
			// Does this k:v match the saved?
			if breakValue[k] == v[0] {
				return "", "", false
			}
			breakValue[k] = v[0]
			return k, v[0], true
		}
	}
	return "", "", false
}

func newEntity(ohi *integration.Integration, api Api) (e *integration.Entity, err error) {
	return ohi.Entity(api.Url, getConfig().Integrationname)
	//return ohi.LocalEntity(), nil
}

func discard(s string, discards []string) bool {
	for _, d := range discards {
		if strings.HasPrefix(s, d) {
			return true
		}
	}
	return false
}
