package main

import (
	"gopkg.in/yaml.v2"
	"io/ioutil"
	"log"
)

type Config struct {
	// 	Urls []string
	Integrationname string
	Integrationversion string
	Apis []Api
}

// No camelcase variable names, it breaks the yaml parser
type Api struct {
	Source string
	Debug bool
	Url     string
	Split   []string
	Discard []string
}

var config = Config{}

func getConfig() *Config {
	return &config
}

func init() {
	yamlFile, err := ioutil.ReadFile("./config.yaml")
	if err != nil {
		log.Fatalf("yamlFile.Get err   #%v ", err)
	}

	err = yaml.Unmarshal(yamlFile, &config)
	if err != nil {
		log.Fatalf("Unmarshal: %v", err)
	}
	//log.Printf("%+v", config)
}
